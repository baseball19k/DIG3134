<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="basketquiz_result.php" method="post" id="basketquiz">

          <!--question1-->
          <div class="quizImage">
            <img src="Pictures/basketballexam.jfif" alt="basketball">
          </div>
          <div class="question">
            <h2>What sport is this for?</h2>
          </div>
            <div class="answerleft">
              <input type="radio" name="which_sport" value="football"><h4>Football</h4>
            </div>
            <div class="answerright">
              <input type="radio" name="which_sport" value="cricket"><h4>Cricket</h4>
            </div>
            <div class="answerleft">
              <input type="radio" name="which_sport" value="soccer"><h4>Soccer</h4>
            </div>
            <div class="answerright">
              <input type="radio" name="which_sport" value="basketball"><h4>Basketball</h4>
            </div>

            <!--question2-->
          <div class="quizImage">
            <img src="Pictures/mj.jfif" alt="Michael Jordan">
          </div>
          <div class="question">
            <h2>Who is this?</h2>
          </div>
            <div class="answerleft">
              <input type="radio" name="mj" value="brady"><h4>Tom Brady</h4>
            </div>
            <div class="answerright">
              <input type="radio" name="mj" value="james"><h4>Lebron James</h4>
            </div>
            <div class="answerleft">
              <input type="radio" name="mj" value="jordan"><h4>Michael Jordan</h4>
            </div>
            <div class="answerright">
              <input type="radio" name="mj" value="jeter"><h4>Derek Jeter</h4>
            </div>

            <!--question3-->
            <div class="quizImage">
              <img src="Pictures/3point.jpg" alt="three pointer">
            </div>
            <div class="question">
              <p>If you make a shot from here how many points do you get?</p>
            </div>
              <div class="answerleft">
                <input type="radio" name="points" value="3"><h4>3</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="points" value="2"><h4>2</h4>
              </div>
              <div class="answerleft">
                <input type="radio" name="points" value="5"><h4>5</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="points" value="1"><h4>1</h4>
              </div>

            <!--question4-->
            <div class="quizImage">
              <img src="Pictures/celticslogo.png" alt="Celtics">
            </div>
            <div class="question">
              <p>What is the name of this team?</p>
            </div>
              <div class="answerleft">
                <input type="radio" name="logo" value="miami"><h4>Miami Heat</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="logo" value="boston"><h4>Boston Celtics</h4>
              </div>
              <div class="answerleft">
                <input type="radio" name="logo" value="la"><h4>LA Lakers</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="logo" value="dallas"><h4>Dallas Mavericks</h4>
              </div>

            <!--question5-->
            <div class="quizImage">
              <img src="Pictures/pgpic.jfif" alt="PG">
            </div>
            <div class="question">
              <p>What team does he play for?</p>
            </div>
              <div class="answerleft">
                <input type="radio" name="pg" value="thunder"><h4>OKC Thunder</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="pg" value="pacers"><h4>Indiana Pacers</h4>
              </div>
              <div class="answerleft">
                <input type="radio" name="pg" value="lakers"><h4>LA Lakers</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="pg" value="clippers"><h4>LA Clippers</h4>
              </div>

            <!--question6-->
            <div class="quizImage">
              <img src="Pictures/kobe.jfif" alt="Kobe">
            </div>
            <div class="question">
              <p>How many championships has he won?</p>
            </div>
              <div class="answerleft">
                <input type="radio" name="kobe" value="3"><h4>3</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="kobe" value="2"><h4>2</h4>
              </div>
              <div class="answerleft">
                <input type="radio" name="kobe" value="5"><h4>5</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="kobe" value="1"><h4>1</h4>
              </div>

            <!--question7-->
            <div class="question">
              <p>If you stop dribbling the ball and you start dribbling again what type of violation is this?</p>
            </div>
              <div class="answerleft">
                <input type="radio" name="penalties" value="traveling"><h4>Traveling</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="penalties" value="carrying"><h4>Carrying</h4>
              </div>
              <div class="answerleft">
                <input type="radio" name="penalties" value="technical"><h4>Technical Foul</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="penalties" value="double"><h4>Double Dribble</h4>
              </div>


              <!--question8-->
              <div class="question">
                <p>What position is typically called the 4 spot?</p>
              </div>
              <div class="answerleft">
                <input type="radio" name="positions" value="smallForward"><h4>Small Forward</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="positions" value="powerForward"><h4>Power Forward</h4>
              </div>
              <div class="answerleft">
                <input type="radio" name="positions" value="center"><h4>Center</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="positions" value="pointGuard"><h4>Point Guard</h4>
              </div>

            <!--question9-->
            <div class="question">
              <p>What position is used for tip offs?</p>
            </div>
              <div class="answerleft">
                <input type="radio" name="tipoff" value="smallForward"><h4>Small Forward</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="tipoff" value="powerForward"><h4>Power Forward</h4>
              </div>
              <div class="answerleft">
                <input type="radio" name="tipoff" value="center"><h4>Center</h4>
              </div>
              <div class="answerright">
                <input type="radio" name="tipoff" value="pointGuard"><h4>Point Guard</h4>
              </div>

          <!--question10-->
          <div class="question">
            <p>How many quarters are in a basketball game?</p>
          </div>
            <div class="answerleft">
              <input type="radio" name="quarters" value="3"><h4>3</h4>
            </div>
            <div class="answerright">
              <input type="radio" name="quarters" value="4"><h4>4</h4>
            </div>
            <div class="answerleft">
              <input type="radio" name="quarters" value="5"><h4>5</h4>
            </div>
            <div class="answerright">
              <input type="radio" name="quarters" value="2"><h4>2</h4>
            </div>
            <input type="submit" name="submit" value="Next">
    </form>
  </body>
</html>
