<?php
  define('db_server', 'localhost');
  define('db_username', 'ja213385');
  define('db_password', 'Ba$eball19k');
  define('db_database', 'ja213385');
  $db = mysqli_connect(db_server, db_username, db_password, db_database);
 ?>
