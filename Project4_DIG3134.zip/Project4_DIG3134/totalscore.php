<?php
#I want it to pull from the database on how many points have been collected in total out of 40 and then depending on how many points they get is what title they get with their name like a badge for the profile. i want the scores from the other games to be sent to the database and stored there. 
 ?>
